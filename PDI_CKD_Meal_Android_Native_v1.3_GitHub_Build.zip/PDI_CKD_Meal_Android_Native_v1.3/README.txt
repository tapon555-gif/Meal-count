PDI & CKD Meal Count Android v1.3
- Fully offline after install
- Deli S228WB works as Bluetooth HID keyboard
- Keeps screen awake while app is open
- Employee IDs embedded in app
- Scan data stored locally in WebView localStorage
- CSV/TXT export uses native Android storage and saves to Downloads/PDI_CKD_Meal/
- CSV can then be uploaded to localhost V3.20.9

EASY ONLINE BUILD (GitHub):
1. Create a new empty GitHub repository.
2. Upload ALL files/folders from this project ZIP to the repository root.
3. Open Actions > Build APK > Run workflow.
4. When complete, open the workflow run and download artifact: PDI-CKD-Meal-Count-APK.
5. Extract the downloaded artifact ZIP; install app-debug.apk on Android.

No Netlify or internet is needed to use the installed app.
